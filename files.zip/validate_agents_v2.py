"""
validate_agents_v2.py — Walidator struktury ROPE 2.0
=====================================================
Poprawki względem v1:
  - CRLF-safe: normalizacja \\r\\n → \\n przed parsowaniem
  - ROPE_VERSION: wykrywa komentarz HTML <!-- ROPE_VERSION: 2.0 -->
  - SYSTEM_PAYLOAD: lepsza ekstrakcja bloku (ignoruje CRLF)
  - runtime_exists: tryb offline gdy RUNTIME_DIR nie istnieje
  - Paths: argument --gemy-dir do nadpisania ścieżki lokalnej
  - Scoring: kara za brak ROPE_VERSION 2.0 obniżona z 10 do 5 (runtime penalty ważniejszy)

Użycie:
  python validate_agents_v2.py [--gemy-dir ŚCIEŻKA] [--runtime-dir ŚCIEŻKA] [--report] [--agents 01 07]
"""

import argparse
import re
import sys
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# KONFIGURACJA DOMYŚLNA
# ---------------------------------------------------------------------------

DEFAULT_GEMY_DIR    = Path(".")   # uruchamiany z katalogu z agentami
DEFAULT_RUNTIME_DIR = None        # None = tryb offline, brak kary za runtime

REQUIRED_SECTIONS = [
    (r"##\s+🧠\s+I\.\s+INTERNAL REASONING|##\s+I\.\s+INTERNAL REASONING|#+\s+INTERNAL REASONING",
     "I. INTERNAL REASONING"),
    (r"##\s+🎭\s+II\.\s+ROLE|##\s+II\.\s+ROLE|#+\s+ROLE\b",
     "II. ROLE"),
    (r"##\s+🎯\s+III\.\s+OBJECTIVE|##\s+III\.\s+OBJECTIVE|#+\s+OBJECTIVE\b",
     "III. OBJECTIVE"),
    (r"##\s+⚙️\s+IV\.\s+PARAMETERS|##\s+IV\.\s+PARAMETERS|#+\s+PARAMETERS\b",
     "IV. PARAMETERS"),
    (r"##\s+📊\s+V\.\s+EVALUATION|##\s+V\.\s+EVALUATION|#+\s+EVALUATION\b",
     "V. EVALUATION"),
    (r"##\s+🔌\s+VI\.\s+SYSTEM_PAYLOAD|##\s+VI\.\s+SYSTEM_PAYLOAD|#+\s+SYSTEM.PAYLOAD\b",
     "VI. SYSTEM_PAYLOAD"),
]

PAYLOAD_FIELDS = [
    "agent_id",
    "status",
    "compressed_output",
    "key_findings",
    "recommended_next_agent",
    "required_context_for_next",
    "anomalies",
    "maturity_score",
]

AGENT_MAP = {
    "01": "MPG",  "02": "PWB",  "03": "CVA",  "04": "QPA",  "05": "SAP",
    "06": "BL",   "07": "ARB",  "08": "EGO",  "09": "CTG",  "10": "ECHO",
    "11": "CEC",  "12": "ROA",  "13": "AOR",  "14": "LCA",  "15": "DBI",
    "16": "UXD",  "17": "DCA",  "18": "SNE",  "19": "QTE",  "20": "SEO",
    "21": "EDU",  "22": "PCH",  "23": "VAP",  "24": "SMM",  "25": "TLO",
    "26": "CRM",  "27": "PFT",  "28": "CSO",  "29": "KMS",  "30": "HRR",
    "31": "PMO",  "32": "TWR",
}


# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------

def normalize(text: str) -> str:
    """Normalizuje CRLF → LF i usuwa BOM."""
    return text.replace("\r\n", "\n").replace("\r", "\n").lstrip("\ufeff")


def read_file(path: Path) -> str:
    for enc in ("utf-8", "utf-8-sig", "cp1250"):
        try:
            return normalize(path.read_text(encoding=enc))
        except (UnicodeDecodeError, LookupError):
            continue
    return normalize(path.read_bytes().decode("utf-8", errors="replace"))


# ---------------------------------------------------------------------------
# WALIDATORY
# ---------------------------------------------------------------------------

def check_sections(content: str) -> list[str]:
    missing = []
    for pattern, label in REQUIRED_SECTIONS:
        if not re.search(pattern, content, re.IGNORECASE):
            missing.append(label)
    return missing


def check_payload_fields(content: str) -> list[str]:
    """
    Wyodrębnia blok SYSTEM_PAYLOAD z sekcji kodu (```...```).
    Akceptuje warianty:
      ``` lub ```yaml lub ``` (bez języka)
    Ignoruje CRLF.
    """
    # Próba 1: blok ``` zawierający ---\nSYSTEM_PAYLOAD
    code_block = re.search(
        r"```[^\n]*\n---\nSYSTEM_PAYLOAD\n(.+?)---\n```",
        content,
        re.DOTALL,
    )
    if code_block:
        block = code_block.group(1)
        return [f for f in PAYLOAD_FIELDS if f not in block]

    # Próba 2: sekcja VI zawierająca SYSTEM_PAYLOAD gdziekolwiek
    section = re.search(
        r"#{1,3}[^\n]*SYSTEM.PAYLOAD(.+?)(?=\n#{1,3} |\Z)",
        content,
        re.DOTALL | re.IGNORECASE,
    )
    if section:
        block = section.group(1)
        return [f for f in PAYLOAD_FIELDS if f not in block]

    # Próba 3: fallback — całe plik
    missing = [f for f in PAYLOAD_FIELDS if f not in content]
    if len(missing) == len(PAYLOAD_FIELDS):
        return ["SYSTEM_PAYLOAD — blok nie znaleziony"]
    return missing


def check_acronym(content: str, expected: str) -> list[str]:
    issues = []
    if re.search(r"\bSKS\b", content):
        issues.append("Zdeprecjonowany akronim SKS (powinno być ARB)")
    header = re.match(r"#\s+\[?\d{2}-([A-Z]+)\]?", content)
    if header and header.group(1) != expected:
        issues.append(f"Nagłówek '{header.group(1)}' != canonical '{expected}'")
    return issues


def check_rope_version(content: str) -> bool:
    # Akceptuje: <!-- ROPE_VERSION: 2.0 --> oraz ROPE_VERSION: 2.0 w tekście
    return bool(re.search(r"ROPE_VERSION:\s*2\.0", content))


def check_runtime(akronim: str, runtime_dir: Path | None) -> bool:
    if runtime_dir is None or not runtime_dir.exists():
        return True  # tryb offline — brak kary
    return any(runtime_dir.glob(f"{akronim}*.prompt.md")) or \
           any(runtime_dir.glob(f"{akronim} - *.prompt.md"))


# ---------------------------------------------------------------------------
# WALIDACJA AGENTA
# ---------------------------------------------------------------------------

def validate_agent(nr: str, akronim: str, gemy_dir: Path, runtime_dir: Path | None) -> dict:
    result = {
        "nr": nr,
        "akronim": akronim,
        "file_found": False,
        "rope_2_0": False,
        "runtime_exists": True,
        "missing_sections": [],
        "missing_payload_fields": [],
        "acronym_issues": [],
        "score": 0,
        "status": "FAIL",
    }

    # Szukaj pliku agenta (nr na początku nazwy)
    doc_file: Path | None = None
    for f in sorted(gemy_dir.glob("*.md")):
        if f.suffix == ".md" and not f.name.endswith(".bak") \
                and re.match(rf"^{nr}\s*[-–\s]", f.name):
            doc_file = f
            break

    if doc_file is None:
        result["missing_sections"] = ["PLIK NIE ZNALEZIONY"]
        return result

    result["file_found"] = True
    content = read_file(doc_file)

    result["missing_sections"]      = check_sections(content)
    result["missing_payload_fields"] = check_payload_fields(content)
    result["acronym_issues"]         = check_acronym(content, akronim)
    result["rope_2_0"]               = check_rope_version(content)
    result["runtime_exists"]         = check_runtime(akronim, runtime_dir)

    # Scoring (0–100)
    penalties = 0
    penalties += len(result["missing_sections"]) * 10
    penalties += len(result["missing_payload_fields"]) * 5
    penalties += len(result["acronym_issues"]) * 15
    penalties += 0 if result["rope_2_0"] else 5
    penalties += 0 if result["runtime_exists"] else 5

    result["score"]  = max(0, 100 - penalties)
    result["status"] = "PASS" if result["score"] >= 85 and not result["missing_sections"] else "FAIL"
    return result


# ---------------------------------------------------------------------------
# OUTPUT
# ---------------------------------------------------------------------------

def print_report(results: list[dict]) -> None:
    passed = [r for r in results if r["status"] == "PASS"]
    failed = [r for r in results if r["status"] == "FAIL"]
    no_file = [r for r in results if "PLIK NIE ZNALEZIONY" in r["missing_sections"]]

    print(f"\n{'='*65}")
    print(f"RAPORT WALIDACYJNY ROPE 2.0 — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*65}")
    print(f"Zbadanych: {len(results)} | ✅ PASS: {len(passed)} | ❌ FAIL: {len(failed)} | 🔍 BRAK PLIKU: {len(no_file)}")

    if failed:
        print(f"\n{'─'*65}")
        print("❌ FAILED:")
        for r in failed:
            issues = r["missing_sections"] + r["missing_payload_fields"] + r["acronym_issues"]
            rope_warn    = "" if r["rope_2_0"]        else " | brak ROPE_VERSION:2.0"
            runtime_warn = "" if r["runtime_exists"]  else " | brak runtime"
            print(f"  [{r['nr']}-{r['akronim']:4s}] score={r['score']:3d} | {', '.join(issues[:3])}{rope_warn}{runtime_warn}")

    if passed:
        print(f"\n{'─'*65}")
        print("✅ PASSED:")
        for r in passed:
            print(f"  [{r['nr']}-{r['akronim']:4s}] score={r['score']:3d}")

    print(f"{'='*65}\n")


def save_markdown_report(results: list[dict], out_path: Path) -> None:
    today = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        "# Raport Walidacyjny ROPE 2.0 (v2 parser)",
        f"**Data:** {today}",
        f"**Agentów zbadanych:** {len(results)}",
        "",
        "| Nr | Akronim | Score | Status | Brakujące sekcje | Payload | Akronim | Runtime |",
        "|:--:|:---:|:---:|:---:|---|---|---|:---:|",
    ]
    for r in results:
        sec = ", ".join(r["missing_sections"]) if r["missing_sections"] else "✅"
        pay = ", ".join(r["missing_payload_fields"][:2]) if r["missing_payload_fields"] else "✅"
        acr = ", ".join(r["acronym_issues"]) if r["acronym_issues"] else "✅"
        rt  = "✅" if r["runtime_exists"] else "❌"
        st  = "✅ PASS" if r["status"] == "PASS" else "❌ FAIL"
        lines.append(f"| {r['nr']} | {r['akronim']} | {r['score']} | {st} | {sec} | {pay} | {acr} | {rt} |")

    out_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"Raport zapisano: {out_path}")


# ---------------------------------------------------------------------------
# ENTRY POINT
# ---------------------------------------------------------------------------

def run(gemy_dir: Path, runtime_dir: Path | None, agent_filter: list[str] | None, save_report: bool) -> None:
    targets = agent_filter if agent_filter else list(AGENT_MAP.keys())
    padded  = [t.zfill(2) for t in targets]
    results = [
        validate_agent(nr, AGENT_MAP[nr], gemy_dir, runtime_dir)
        for nr in padded if nr in AGENT_MAP
    ]

    print_report(results)

    if save_report:
        report_path = gemy_dir / "validation_report_v2.md"
        save_markdown_report(results, report_path)

    fail_count = sum(1 for r in results if r["status"] == "FAIL")
    sys.exit(1 if fail_count > 0 else 0)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Walidator ROPE 2.0 dla 32 agentów (v2)")
    parser.add_argument("--gemy-dir",    type=Path, default=DEFAULT_GEMY_DIR,
                        help="Ścieżka do katalogu z plikami agentów .md")
    parser.add_argument("--runtime-dir", type=Path, default=DEFAULT_RUNTIME_DIR,
                        help="Ścieżka do katalogu runtime .prompt.md (opcjonalna)")
    parser.add_argument("--report",      action="store_true",
                        help="Zapisuje raport Markdown")
    parser.add_argument("--agents",      nargs="+", metavar="NR",
                        help="Weryfikuje tylko podane numery agentów (np. 01 07)")
    args = parser.parse_args()
    run(
        gemy_dir=args.gemy_dir,
        runtime_dir=args.runtime_dir,
        agent_filter=args.agents,
        save_report=args.report,
    )
