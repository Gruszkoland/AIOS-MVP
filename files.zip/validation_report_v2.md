# Raport Walidacyjny ROPE 2.0 (v2 parser)
**Data:** 2026-04-22 18:48:40
**Agentów zbadanych:** 32

| Nr | Akronim | Score | Status | Brakujące sekcje | Payload | Akronim | Runtime |
|:--:|:---:|:---:|:---:|---|---|---|:---:|
| 01 | MPG | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 02 | PWB | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 03 | CVA | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 04 | QPA | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 05 | SAP | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 06 | BL | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 07 | ARB | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 08 | EGO | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 09 | CTG | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 10 | ECHO | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 11 | CEC | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 12 | ROA | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 13 | AOR | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 14 | LCA | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 15 | DBI | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 16 | UXD | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 17 | DCA | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 18 | SNE | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 19 | QTE | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 20 | SEO | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 21 | EDU | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 22 | PCH | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 23 | VAP | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 24 | SMM | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 25 | TLO | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 26 | CRM | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 27 | PFT | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 28 | CSO | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 29 | KMS | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 30 | HRR | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 31 | PMO | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |
| 32 | TWR | 100 | ✅ PASS | ✅ | ✅ | ✅ | ✅ |