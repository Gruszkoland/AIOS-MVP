"""
validate_agents_v3.py — Walidator ROPE 2.1
Nowe testy vs v2: placeholder detection, content quality,
INPUT_SCHEMA, INVOKE_WHEN, ESCALATION_PATH, USER_FACING_OUTPUT,
modes_output_coverage, maturity floor, neg_domain count.
"""
import argparse, re, sys
from datetime import datetime
from pathlib import Path

DEFAULT_GEMY_DIR = Path(".")

REQUIRED_SECTIONS = [
    (r"## 🧠 I\. INTERNAL REASONING|## I\. INTERNAL REASONING", "I. INTERNAL REASONING"),
    (r"## 🎭 II\. ROLE|## II\. ROLE", "II. ROLE"),
    (r"## 🎯 III\. OBJECTIVE|## III\. OBJECTIVE", "III. OBJECTIVE"),
    (r"## ⚙️ IV\. PARAMETERS|## IV\. PARAMETERS", "IV. PARAMETERS"),
    (r"## 📊 V\. EVALUATION|## V\. EVALUATION", "V. EVALUATION"),
    (r"## 🔌 VI\. SYSTEM_PAYLOAD|## VI\. SYSTEM_PAYLOAD", "VI. SYSTEM_PAYLOAD"),
]

PAYLOAD_FIELDS = ["agent_id","status","compressed_output","key_findings",
                  "recommended_next_agent","required_context_for_next","anomalies","maturity_score"]

AGENT_MAP = {
    "01":"MPG","02":"PWB","03":"CVA","04":"QPA","05":"SAP","06":"BL","07":"ARB","08":"EGO",
    "09":"CTG","10":"ECHO","11":"CEC","12":"ROA","13":"AOR","14":"LCA","15":"DBI","16":"UXD",
    "17":"DCA","18":"SNE","19":"QTE","20":"SEO","21":"EDU","22":"PCH","23":"VAP","24":"SMM",
    "25":"TLO","26":"CRM","27":"PFT","28":"CSO","29":"KMS","30":"HRR","31":"PMO","32":"TWR","33":"EVA",
}

def normalize(t): return t.replace("\r\n","\n").replace("\r","\n").lstrip("\ufeff")
def read_file(p):
    for enc in ("utf-8","utf-8-sig","cp1250"):
        try: return normalize(p.read_text(encoding=enc))
        except: continue
    return normalize(p.read_bytes().decode("utf-8",errors="replace"))

def check_sections(c): return [l for p,l in REQUIRED_SECTIONS if not re.search(p,c,re.IGNORECASE)]

def check_payload(c):
    blk = re.search(r"```[^\n]*\n---\nSYSTEM_PAYLOAD\n(.+?)---\n```",c,re.DOTALL)
    if blk: return [f for f in PAYLOAD_FIELDS if f not in blk.group(1)]
    sec = re.search(r"#{1,3}[^\n]*SYSTEM.PAYLOAD(.+?)(?=\n#{1,3} |\Z)",c,re.DOTALL|re.IGNORECASE)
    if sec: return [f for f in PAYLOAD_FIELDS if f not in sec.group(1)]
    return ["SYSTEM_PAYLOAD blok nie znaleziony"]

def check_acronym(c, exp):
    issues = []
    if re.search(r"\bSKS\b",c): issues.append("zdeprecjonowany akronim SKS")
    h = re.match(r"#\s+\[?\d{2}-([A-Z]+)\]?",c)
    if h and h.group(1)!=exp: issues.append(f"nagłówek '{h.group(1)}' != '{exp}'")
    return issues

def check_rope_version(c): return bool(re.search(r"ROPE_VERSION:\s*2\.[01]",c))

# --- NEW v3 checks ---
def check_no_placeholders(c):
    return len(re.findall(r"Uzupełnić na podstawie oryginału",c))

def check_input_schema(c): return "INPUT_SCHEMA:" in c
def check_invoke_when(c):  return "INVOKE_WHEN:" in c
def check_escalation(c):   return "ESCALATION_PATH:" in c
def check_user_facing(c):  return "USER_FACING_OUTPUT:" in c

def check_modes_output_coverage(c):
    modes = re.findall(r"\*\*[A-D]\. [A-Z_]+_MODE\*\*(.+?)(?=\n\*\*[A-D]\.|---|\n##)",c,re.DOTALL)
    if not modes: return 0, 0
    with_out = sum(1 for m in modes if "Output:" in m or "output:" in m)
    return len(modes), with_out

def check_neg_domain(c):
    negs = re.findall(r"- Nie .+",c)
    return len([n for n in negs if not any(g in n for g in ["lania wody","uzasadni","halucyn","symulujesz dostępu"])])

def check_maturity(c):
    m = re.search(r"maturity_score:\s*(\d+)",c)
    return int(m.group(1)) if m else 0

def check_version_21(c): return bool(re.search(r"\*\*Wersja:\*\*\s*2\.1",c))

def validate_agent(nr, akronim, gemy_dir):
    result = dict(nr=nr, akronim=akronim, file_found=False, rope=False,
                  missing_sections=[], missing_payload=[], acronym_issues=[],
                  placeholders=0, has_input_schema=False, has_invoke_when=False,
                  has_escalation=False, has_user_facing=False,
                  modes_total=0, modes_with_output=0, neg_domain_count=0,
                  maturity=0, version_21=False, score=0, status="FAIL")

    doc = None
    for f in sorted(gemy_dir.glob("*.md")):
        if not f.name.endswith(".bak") and re.match(rf"^{nr}\s*[-–\s]",f.name):
            doc = f; break

    if doc is None:
        result["missing_sections"] = ["PLIK NIE ZNALEZIONY"]
        return result

    result["file_found"] = True
    c = read_file(doc)

    result["missing_sections"]   = check_sections(c)
    result["missing_payload"]    = check_payload(c)
    result["acronym_issues"]     = check_acronym(c, akronim)
    result["rope"]               = check_rope_version(c)
    result["placeholders"]       = check_no_placeholders(c)
    result["has_input_schema"]   = check_input_schema(c)
    result["has_invoke_when"]    = check_invoke_when(c)
    result["has_escalation"]     = check_escalation(c)
    result["has_user_facing"]    = check_user_facing(c)
    mt, mo                       = check_modes_output_coverage(c)
    result["modes_total"]        = mt
    result["modes_with_output"]  = mo
    result["neg_domain_count"]   = check_neg_domain(c)
    result["maturity"]           = check_maturity(c)
    result["version_21"]         = check_version_21(c)

    # Scoring
    p = 0
    p += len(result["missing_sections"])  * 10
    p += len(result["missing_payload"])   * 5
    p += len(result["acronym_issues"])    * 15
    p += 0 if result["rope"]             else 5
    p += result["placeholders"]          * 10   # -10 per unfilled placeholder
    p += 0 if result["has_input_schema"] else 5
    p += 0 if result["has_invoke_when"]  else 5
    p += 0 if result["has_escalation"]  else 5
    p += 0 if result["has_user_facing"]  else 3
    # modes output gap
    gap = result["modes_total"] - result["modes_with_output"]
    p += gap * 2
    # neg domain
    if result["neg_domain_count"] < 2: p += 5
    # maturity
    if result["maturity"] < 3: p += 3

    result["score"] = max(0, 100 - p)
    result["status"] = "PASS" if result["score"] >= 85 and not result["missing_sections"] and result["placeholders"] == 0 else "FAIL"
    return result

def print_report(results):
    passed = [r for r in results if r["status"]=="PASS"]
    failed = [r for r in results if r["status"]=="FAIL"]
    print(f"\n{'='*70}")
    print(f"RAPORT WALIDACYJNY ROPE 2.1 — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"{'='*70}")
    print(f"Zbadanych: {len(results)} | ✅ PASS: {len(passed)} | ❌ FAIL: {len(failed)}")
    if failed:
        print(f"\n{'─'*70}\n❌ FAILED:")
        for r in failed:
            issues = []
            if r["missing_sections"]: issues.append(f"sections:{r['missing_sections']}")
            if r["placeholders"]:     issues.append(f"stubs:{r['placeholders']}")
            if not r["has_input_schema"]: issues.append("no_INPUT_SCHEMA")
            if not r["has_invoke_when"]:  issues.append("no_INVOKE_WHEN")
            if not r["has_escalation"]:   issues.append("no_ESCALATION")
            gap = r["modes_total"]-r["modes_with_output"]
            if gap: issues.append(f"mode_gap:{gap}")
            print(f"  [{r['nr']}-{r['akronim']:4s}] score={r['score']:3d} | {' | '.join(issues[:4])}")
    if passed:
        print(f"\n{'─'*70}\n✅ PASSED:")
        for r in passed:
            mat_flag = "" if r["maturity"] >= 3 else f" ⚠️mat={r['maturity']}"
            print(f"  [{r['nr']}-{r['akronim']:4s}] score={r['score']:3d} mat={r['maturity']}{mat_flag}")
    print(f"{'='*70}\n")

def save_report(results, out_path):
    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = [
        "# Raport Walidacyjny ROPE 2.1",
        f"**Data:** {today} | **Zbadanych:** {len(results)}",
        "",
        "| Nr | Akronim | Score | Status | Stubs | InpSch | Invoke | Esc | UF | ModGap | NegD | Mat | Ver |",
        "|:--:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|",
    ]
    for r in results:
        gap = r["modes_total"]-r["modes_with_output"]
        st = "✅" if r["status"]=="PASS" else "❌"
        lines.append(
            f"| {r['nr']} | {r['akronim']} | {r['score']} | {st} "
            f"| {'✅' if r['placeholders']==0 else str(r['placeholders'])} "
            f"| {'✅' if r['has_input_schema'] else '❌'} "
            f"| {'✅' if r['has_invoke_when'] else '❌'} "
            f"| {'✅' if r['has_escalation'] else '❌'} "
            f"| {'✅' if r['has_user_facing'] else '❌'} "
            f"| {'✅' if gap==0 else f'❌{gap}'} "
            f"| {r['neg_domain_count']} "
            f"| {r['maturity']} "
            f"| {'✅' if r['version_21'] else '⚠️'} |"
        )
    out_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"Raport v3 zapisano: {out_path}")

def run(gemy_dir, agent_filter, save):
    targets = agent_filter or list(AGENT_MAP.keys())
    results = [validate_agent(nr.zfill(2), AGENT_MAP[nr.zfill(2)], gemy_dir)
               for nr in targets if nr.zfill(2) in AGENT_MAP]
    print_report(results)
    if save:
        save_report(results, gemy_dir/"validation_report_v3.md")
    sys.exit(1 if any(r["status"]=="FAIL" for r in results) else 0)

if __name__=="__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--gemy-dir", type=Path, default=DEFAULT_GEMY_DIR)
    p.add_argument("--report",   action="store_true")
    p.add_argument("--agents",   nargs="+", metavar="NR")
    args = p.parse_args()
    run(args.gemy_dir, args.agents, args.report)
