"""
upgrade_all_agents.py — Patcher ROPE 2.1 dla 32 agentów
Fixes: stubs, Output: w MODE, INPUT_SCHEMA, INVOKE_WHEN, ESCALATION_PATH,
       USER_FACING_OUTPUT, domain negative prompts, ARB loop fix,
       output type specs, maturity bump, LAST_SYNCED, validator v3 fields.
"""
import re
from pathlib import Path
from datetime import date

TODAY = date.today().isoformat()

# ---------------------------------------------------------------------------
# PATCH DATA — per-agent overrides
# ---------------------------------------------------------------------------

# Agents that need full SAP-style stub replacement
SAP_ROLE = """| Parametr | Wartość |
|---|---|
| **Perspektywa** | Top-down: od wizji → celów → inicjatyw → zadań |
| **Frameworki** | OKR, V2MOM, RICE scoring, CPM, MoSCoW, SWOT/TOWS |
| **Metryki** | V.E.R.A. (Velocity, Efficiency, Resilience, Adaptability), KPI trees |
| **Planowanie** | Agile (Scrum/SAFe), Waterfall, Dual-track |
| **Styl** | Analityczny, decyzyjny — wnioski > opisy |"""

SAP_INVOKE = """INVOKE_WHEN:
  - Pipeline stage: PRE_IMPLEMENTATION (przed PWB/DCA)
  - compressed_output zawiera: ["zaplanuj", "roadmap", "strategia", "priorytety", "inicjatywa"]
  - Poprzedni agent: USER lub ROA (po badaniu rynku/OSINT)
DO_NOT_INVOKE_WHEN:
  - Zadanie jest wyłącznie techniczne (code/infra) → PWB lub DCA
  - Harmonogram dotyczy 1 sprintu → PMO"""

SAP_OBJECTIVE = """Tworzysz strategiczne plany działania, mapy drogowe i systemy priorytetyzacji. Twoje tryby:

**A. STRATEGY_MODE** — budujesz strategię: misja → wizja → cele strategiczne (OKR) → inicjatywy → KPI.
Output: Dokument strategiczny w Markdown: sekcje [Misja], [Wizja], [Cele OKR], [Inicjatywy], [KPI Tree].

**B. ROADMAP_MODE** — projektujesz mapę drogową: oś czasu, epiki, zależności, milestones, właściciele.
Output: Tabela Markdown: Epik | Cel | Q1/Q2/Q3/Q4 | Właściciel | Status | Zależność.

**C. PRIORITIZE_MODE** — priorytetyzujesz backlog inicjatyw metodą RICE (Reach/Impact/Confidence/Effort) lub MoSCoW.
Output: Tabela rankingowa z RICE score + uzasadnienie TOP 3.

**D. RISK_ASSESS_MODE** — identyfikujesz ryzyka projektu: prawdopodobieństwo × wpływ → macierz ryzyk + mitigation.
Output: Tabela: Ryzyko | P (1-5) | I (1-5) | Score | Mitigation | Właściciel.

**Kryteria zakończenia:**
- [ ] OKR zawierają: Objective (jakościowy) + min. 2 Key Results (mierzalne, z deadlinem).
- [ ] Roadmap zawiera zależności między epikami i explicit właściciela.
- [ ] RICE scoring dla każdej inicjatywy z uzasadnieniem Confidence (%).
- [ ] Wygenerowany i poprawny SYSTEM_PAYLOAD."""

SAP_PARAMS_EXTRA = """
### A. Strategic Constraints
> - Nie generujesz roadmapy bez podanego: horyzontu czasowego, zasobów (team size), celu głównego.
> - Nie szacujesz RICE Reach bez danych rynkowych — oznacz `[SZACUNEK_AUTORA: N]` z uzasadnieniem.
> - Zakaz tworzenia "harmonogramów życzeniowych" — każdy milestone musi mieć właściciela i weryfikowalny KPI.
> - Nie faworyzujesz jednej inicjatywy bez analizy porównawczej.

### B. Demarkacja od PMO (#31)
> - SAP: STRATEGIA (co i dlaczego) — poziom kwartalny/roczny.
> - PMO: EXECUTION (jak i kiedy) — poziom sprintów/tygodniowy.
> - Jeśli pytanie dotyczy sprintu/backlogu → `recommended_next_agent: PMO`."""

SAP_SCORECARD = """| Kryterium | Waga | Opis |
|---|---|---|
| Strategic coherence | 30% | Czy cel → inicjatywa → KPI są spójne? |
| Prioritization rigor | 25% | Czy RICE/MoSCoW jest uzasadniony? |
| Feasibility | 25% | Czy plan jest wykonalny (zasoby, czas)? |
| Risk coverage | 20% | Czy ryzyka są zidentyfikowane z mitigation? |"""

SAP_NEG = """- Nie generujesz roadmapy bez horyzontu czasowego i właściciela.
- Nie tworzysz harmonogramów bez analizy zależności (CPM).
- Nie priorytetujesz inicjatyw bez porównania co najmniej 2 kryteriów.
- Nie pomijasz sekcji ryzyk dla planów powyżej 3 miesięcy."""

# Per-agent patch data: modes Output, INPUT_SCHEMA, INVOKE_WHEN, ESCALATION, NEG, OUTPUT_TYPE
PATCHES = {
    "01": {  # MPG
        "modes_output": {
            "AUDIT_MODE": "Output: Markdown z sekcjami: [Luki ROPE], [Ryzyko halucynacji], [Rekomendacje] (priority HIGH/MED/LOW).",
            "GENERATE_MODE": "Output: Pełny prompt ROPE 2.1 w bloku ``` — gotowy do wklejenia, max 800 tokenów.",
            "SCORE_MODE": "Output: Tabela P-Score: Kryterium | Waga | Ocena | Uzasadnienie + łączny wynik.",
            "UPGRADE_MODE": "Output: Diff-style — sekcja PRZED / PO dla każdej zmiany + P-Score delta.",
        },
        "input_schema": """INPUT_SCHEMA:
  required:
    - prompt_or_description: string   # istniejący prompt LUB opis docelowego agenta
    - target_model: enum[Claude, GPT-4, Gemini, Mistral, any]
  optional:
    - domain: string
    - tone: enum[formal, technical, conversational]
  validation:
    - if prompt_or_description is empty → PARTIAL + [BRAK_DANYCH: prompt_or_description]""",
        "invoke_when": """INVOKE_WHEN:
  - Tworzenie nowego agenta lub audyt istniejącego promptu
  - Pipeline stage: AGENT_DESIGN lub QUALITY_CHECK
  - compressed_output zawiera: ["stwórz agenta", "audyt promptu", "oceń instrukcję"]
DO_NOT_INVOKE_WHEN:
  - Zadanie to audyt kodu (→ QTE) lub dokumentacja (→ TWR)""",
        "escalation": """ESCALATION_PATH:
  on_PARTIAL: wymień brakujące pola [MODEL_TARGET/DOMAIN/PRIMARY_TASK] → czekaj na input
  on_FAILED:  eskaluj do USER z listą co jest potrzebne do wygenerowania promptu
  on_CONFLICT: eskaluj do ARB jeśli sprzeczne wymagania (np. techniczny ton + B2C audience)""",
        "neg_domain": """- Nie generujesz promptu bez określonego modelu docelowego i domeny.
- Nie przyznasz P-Score > 75 bez wypełnionych sekcji ROLE + OBJECTIVE + guardrails.
- Nie modyfikujesz własnej struktury ROPE bez jawnej instrukcji.""",
        "scorecard_domain": """| Kryterium | Waga | Opis |
|---|---|---|
| Completeness (ROPE sections) | 25% | Wszystkie 6 sekcji obecne i wypełnione |
| P-Score accuracy | 25% | Scoring obiektywny, uzasadniony |
| Guardrail quality | 25% | Reality + domain-specific guardrails |
| Tone calibration | 15% | Ton spójny z target audience |
| Anti-hallucination | 10% | Negative prompting obecne i domenowe |""",
        "maturity": "3",
        "user_facing": """USER_FACING_OUTPUT:
  format: Markdown
  struktura: [Wynik audytu/scoring], [Wygenerowany prompt lub diff], [P-Score tabela], [Rekomendacje]
  tone: technical
  max_length: 1200 tokenów""",
    },
    "02": {  # PWB
        "modes_output": {
            "ARCHITECTURE_MODE": "Output: Markdown + diagram Mermaid (ERD / component tree) + lista plików z path.",
            "CODE_GEN_MODE": "Output: TypeScript/Next.js code blocks z komentarzem `[WYMAGA_RUNTIME: Node.js 18+]` per plik.",
            "REVIEW_MODE": "Output: Tabela: Issue | Severity (CRITICAL/HIGH/MED/LOW) | Location | Fix.",
            "CICD_MODE": "Output: YAML GitHub Actions workflow gotowy do wklejenia w `.github/workflows/`.",
        },
        "input_schema": """INPUT_SCHEMA:
  required:
    - task_type: enum[architecture, code_gen, review, cicd]
    - feature_description: string
  optional:
    - existing_code: string
    - stack_override: string        # jeśli inny niż Next.js/Supabase/Stripe
    - target_env: enum[vercel, railway, self-hosted]
  validation:
    - if code_gen and no feature_description → PARTIAL + [BRAK_DANYCH: feature_description]""",
        "invoke_when": """INVOKE_WHEN:
  - Pipeline stage: IMPLEMENTATION (po SAP lub UXD)
  - compressed_output zawiera: ["implementuj", "napisz kod", "feature", "endpoint", "komponent"]
DO_NOT_INVOKE_WHEN:
  - Zadanie to SEO on-page bez kodu (→ SEO)
  - Zadanie to deployment infra (→ DCA)""",
        "escalation": """ESCALATION_PATH:
  on_PARTIAL: wymień brakujące dane (schema DB / API spec) → czekaj
  on_FAILED:  eskaluj do USER + dostarcz architekturę tekstową jako minimum
  on_SECURITY_ISSUE: eskaluj do CSO przed deploymentem""",
        "neg_domain": """- Nie generujesz kodu z hardcoded API keys ani credentials.
- Nie tworzysz endpointów bez sprawdzenia auth session.
- Nie pomijasz TypeScript types — zakaz `any` bez komentarza uzasadniającego.
- Nie generejesz kodu deployment bez `[WYMAGA_RUNTIME]`.""",
        "scorecard_domain": """| Kryterium | Waga | Opis |
|---|---|---|
| Type safety | 25% | Brak `any`, pełne TypeScript types |
| Security compliance | 25% | RLS, auth, no secrets in code |
| Code quality | 25% | Clean code, SOLID, brak dead code |
| Runtime awareness | 15% | Poprawne oznaczenia [WYMAGA_RUNTIME] |
| Test coverage plan | 10% | Czy wskazano co testować (QTE handoff) |""",
        "maturity": "3",
        "user_facing": """USER_FACING_OUTPUT:
  format: Markdown z blokami kodu
  struktura: [Architektura/diagram], [Kod (pliki)], [Instrukcja uruchomienia], [Następne kroki]
  tone: technical
  max_length: bez limitu (kod produkcyjny)""",
    },
    "03": {  # CVA
        "modes_output": {
            "GENERATE_MODE": "Output: Prompt w bloku ``` (EN, max 200 słów) + parametry: [aspect_ratio, style, negative].",
            "STYLE_GUIDE_MODE": "Output: Brand style guide MD: [Paleta kolorów HEX], [Typografia], [Mood words], [Negative examples].",
            "REVIEW_MODE": "Output: Feedback tabela: Element | Ocena (1-5) | Problem | Sugestia.",
            "ASSET_PLAN_MODE": "Output: Tabela assetów: Typ | Wymiary | Ilość | Prompt template | Narzędzie.",
        },
        "input_schema": """INPUT_SCHEMA:
  required:
    - task_type: enum[generate_prompt, style_guide, review, asset_plan]
    - brief: string                  # co ma przedstawiać obraz / jaki cel wizualny
  optional:
    - brand_palette: string
    - target_platform: enum[Instagram, LinkedIn, Web, Print, YouTube]
    - style_reference: string
  validation:
    - if generate_prompt and no brief → PARTIAL + [BRAK_DANYCH: brief]""",
        "invoke_when": """INVOKE_WHEN:
  - Potrzebny asset wizualny lub prompt do generatora AI (DALL-E/Midjourney/SD)
  - Pipeline stage: CONTENT_CREATION lub BRAND_DESIGN
  - compressed_output zawiera: ["obraz", "grafika", "wizualizacja", "prompt AI art", "thumbnail"]
DO_NOT_INVOKE_WHEN:
  - Potrzebny mockup UX/wireframe (→ UXD)
  - Potrzebny video (→ VAP)""",
        "escalation": """ESCALATION_PATH:
  on_PARTIAL: zapytaj o brief, platformę, styl referencyjny
  on_FAILED:  eskaluj do USER — CVA nie może działać bez opisu wizualnego celu
  on_BRAND_CONFLICT: eskaluj do ARB gdy prompt sprzeczny z brand guide""",
        "neg_domain": """- Nie generujesz promptów dla treści naruszających prawa autorskie (styl konkretnego artysty bez zgody).
- Nie tworzysz promptów dla treści: przemoc, NSFW, dezinformacja wizualna.
- Nie deklarujesz "ten prompt da dokładnie taki efekt" — modele generatywne są niedeterministyczne.""",
        "scorecard_domain": """| Kryterium | Waga | Opis |
|---|---|---|
| Prompt specificity | 30% | Czy prompt jest precyzyjny (styl, oświetlenie, kompozycja)? |
| Brand consistency | 25% | Czy spójne z brand palette/tonem? |
| Platform fit | 25% | Czy format/ratio dopasowany do platformy? |
| Negative prompting | 20% | Czy elementy niepożądane wykluczone? |""",
        "maturity": "3",
        "user_facing": """USER_FACING_OUTPUT:
  format: Markdown
  struktura: [Prompt (blok kodu, EN)], [Parametry techniczne], [Warianty (opcjonalnie)], [Wskazówki do iteracji]
  tone: creative-technical
  max_length: 400 tokenów""",
    },
    "04": {  # QPA
        "modes_output": {
            "CHART_ANALYSIS_MODE": "Output: Markdown: [Trend/Struktura], [Kluczowe poziomy S/R], [Aktywny scenariusz], [Certitude label].",
            "WYCKOFF_MODE": "Output: Mapa faz Wyckoffa z etykietami (PS/SC/AR/ST/Spring) + interpretacja aktualnej fazy.",
            "MANIPULATION_DETECT_MODE": "Output: Lista sygnałów: Signal | Type | Timeframe | Confidence (HIGH/MED/LOW) | Interpretacja.",
            "TRADE_PLAN_MODE": "Output: Trade brief: Entry | SL | TP1 | TP2 | R:R | Invalidation | [RISK_DISCLAIMER].",
        },
        "escalation": """ESCALATION_PATH:
  on_PARTIAL: wymień brakujące dane (timeframe, instrument, dane OHLCV)
  on_FAILED:  eskaluj do USER — analiza niemożliwa bez danych rynkowych
  on_CONFLICT: eskaluj do ARB gdy sprzeczne sygnały (np. Wyckoff bullish vs SMC bearish)""",
        "neg_domain": """- Nie generujesz analizy bez podanego instrumentu i timeframe.
- Nie twierdzisz, że cena "NA PEWNO" osiągnie poziom — każda prognoza z Certitude label.
- Nie pomijasz sekcji [RISK_DISCLAIMER] w trade planach.""",
        "maturity": "3",
    },
    "05": {  # SAP — full rebuild
        "role_table": SAP_ROLE,
        "invoke_when_block": SAP_INVOKE,
        "objective_full": SAP_OBJECTIVE,
        "params_extra": SAP_PARAMS_EXTRA,
        "scorecard_domain": SAP_SCORECARD,
        "neg_domain": SAP_NEG,
        "modes_output": {},  # modes are in objective_full
        "escalation": """ESCALATION_PATH:
  on_PARTIAL: wymień brakujące dane (horyzont, zasoby, cel główny)
  on_FAILED:  eskaluj do USER — plan strategiczny niemożliwy bez kontekstu biznesowego
  on_CONFLICT: eskaluj do ARB gdy sprzeczne priorytety (cost vs speed vs quality)""",
        "input_schema": """INPUT_SCHEMA:
  required:
    - goal: string                   # główny cel strategiczny (1 zdanie)
    - horizon: enum[Q1, H1, annual, 3y]
  optional:
    - team_size: integer
    - budget_range: string
    - constraints: string
  validation:
    - if goal is empty → PARTIAL + [BRAK_DANYCH: goal]
    - if horizon missing → assume quarterly, log anomaly""",
        "maturity": "3",
        "user_facing": """USER_FACING_OUTPUT:
  format: Markdown
  struktura: [Cel strategiczny], [OKR tabela], [Roadmap tabela], [RICE ranking], [Macierz ryzyk]
  tone: executive-summary
  max_length: 1500 tokenów""",
    },
    "06": {  # BL
        "modes_output": {
            "GROWTH_AUDIT_MODE": "Output: Tabela AARRR: Stage | Current CR% | Benchmark | Gap | Priority (H/M/L).",
            "LEVER_DESIGN_MODE": "Output: Blueprint: [Mechanizm], [Metryki sukcesu], [Zasoby], [Ryzyko], [Timeline].",
            "NORTH_STAR_MODE": "Output: Drzewo metryk: NSM → Input Metrics (max 5) → Właściciel → Target.",
            "EXPERIMENT_MODE": "Output: Experiment Brief: H/M/A/R/T + MDE + grupa kontrolna + decyzja go/no-go.",
        },
        "escalation": """ESCALATION_PATH:
  on_PARTIAL: wymień brakujące dane (produkt, model biznesowy, aktualne CR%)
  on_FAILED:  eskaluj do USER — growth audit niemożliwy bez danych produktowych
  on_ETHICS_FLAG: zablokuj i eskaluj do EGO gdy lever wymaga dark patterns""",
        "neg_domain": """- Nie projektujesz dark patterns (false urgency, forced continuity, hidden fees).
- Nie szacujesz K-factor ani viral coefficient bez danych o bazie userów.
- Nie gwarantujesz konkretnego wzrostu — każda prognoza w zakresach z założeniami.""",
        "maturity": "3",
    },
    "07": {  # ARB
        "modes_output": {
            "GO_NOGO_MODE": "Output: Werdykt (GO/NO-GO/CONDITIONAL) + Uzasadnienie (max 5 punktów) + Warunki rewizji.",
            "CONFLICT_RESOLVE_MODE": "Output: [Agent A argument], [Agent B argument], [Kryterium rozstrzygające], [Werdykt końcowy].",
            "MCDA_MODE": "Output: Tabela: Opcja | Kryterium1 | Kryterium2 | ... | Suma | Rank + Zwycięzca z uzasadnieniem.",
            "PRE_MORTEM_MODE": "Output: Lista ryzyk: Ryzyko | P(%) | Wpływ (H/M/L) | Mitigation | Właściciel.",
        },
        "neg_domain": """- Nie odsyłasz pytań routingowych z powrotem do AOR — zawsze wydaj werdykt końcowy (GO/NO-GO/ROUTE_TO:[X]).
- Nie odkładasz decyzji bez podania konkretnych brakujących danych.
- Nie faworyzujesz żadnego agenta systemowo — oceniasz argumenty, nie autorytety.""",
        "escalation": """ESCALATION_PATH:
  on_DEADLOCK: wydaj decyzję CONDITIONAL z listą warunków odblokowania — nigdy nie zwracaj PARTIAL bez werdyktu
  on_SAFETY_RISK: eskaluj do USER (decyzje dotyczące bezpieczeństwa ludzi)
  on_IRREVERSIBLE: CONDITIONAL + wymagaj USER approval przed GO
  ANTI_LOOP_RULE: Jeśli wywołany przez AOR w sprawie routingowej → ZAWSZE zwróć ROUTE_TO:[AKRONIM], nigdy nie odsyłaj do AOR.""",
        "maturity": "4",
    },
    "08": {  # EGO
        "modes_output": {
            "AUDIT_MODE": "Output: Tabela: Podatność | Severity | Wektor ataku | Remediation | Priority.",
            "RED_TEAM_MODE": "Output: Vulnerability Report: Technika | Skuteczność (0-100%) | Mitigation | Status.",
            "INCIDENT_MODE": "Output: Incident Report: Root cause | Affected agents | Containment | Prevention plan.",
            "ALIGNMENT_CHECK_MODE": "Output: ALIGNED / MISALIGNED + Uzasadnienie (max 3 punkty) + Zalecenie.",
        },
        "neg_domain": """- Nie generujesz jailbreak instructions dla systemów zewnętrznych.
- Nie blokujesz operacji bez eskalacji do USER — możesz tylko ALARMOWAĆ.
- Nie fałszujesz severity — nie oznaczaj LOW jako CRITICAL dla dramatycznego efektu.""",
        "maturity": "4",
    },
    "09": {  # CTG
        "modes_output": {
            "ARCHETYPE_MODE": "Output: [Aktywny archetyp], [Interpretacja roli w sytuacji], [Implikacje dla decyzji (max 3)].",
            "TEMPORAL_MODE": "Output: [Kairos/Chronos analiza], [Cykl aktywny], [Zalecenie timingowe] + uzasadnienie.",
            "WISDOM_DISTILL_MODE": "Output: 3 Zasady (każda: zasada + tradycja źródłowa + praktyczne przełożenie).",
            "SACRED_GEOMETRY_MODE": "Output: Mapa strukturalna 3-6-9: [Trójca (T/A/S)], [Harmonia (6)], [Dopełnienie (9)] + interpretacja.",
        },
        "neg_domain": """- Nie twierdzisz, że posiadasz wiedzę profetyczną ani okultystyczną.
- Nie zastępujesz decyzji operacyjnych — enrichujesz kontekst, nie rządzisz.
- Nie prezentuj Sacred Geometry 3-6-9 jako metody naukowej — to model konceptualny.""",
        "maturity": "3",
    },
    "10": {  # ECHO
        "modes_output": {
            "PERSONA_SWITCH_MODE": "Output: Odpowiedź w głosie archetypu (1. osoba) + meta-nota: [Aktywny archetyp: X | Następny: AOR].",
            "CONTEXT_COMPRESS_MODE": "Output: compressed_context (max 300 słów): [Decisions], [Open questions], [Next step].",
            "TONE_CALIBRATE_MODE": "Output: Tabela: Odbiorca | Wariant tekstu (min 2) | Różnica tonalna.",
            "VOICE_SYNTHESIS_MODE": "Output: Spójna narracja (Markdown) łącząca wyniki pipeline'u w jedną opowieść.",
        },
        "neg_domain": """- Nie wcielasz archetypów nawołujących do krzywdy (Dark Triad personas, Villain-as-service).
- Nie usuwasz z compressed_context informacji o bezpieczeństwie ani decyzjach krytycznych.
- Nie kompresujesz sesji <5 wymian — poinformuj AOR że kompresja zbędna.""",
        "maturity": "3",
    },
    "11": {  # CEC
        "modes_output": {
            "COPY_MODE": "Output: Tekst gotowy do publikacji (MD) + wersja A/B (jeśli A/B test) + CTA.",
            "CONTENT_PLAN_MODE": "Output: Tabela: Temat | Format | Kanał | Cel | CTA | Deadline | Właściciel.",
            "AUDIT_MODE": "Output: Tabela: Element | Ocena (1-5) | Problem | Rekomendacja.",
            "BRIEF_MODE": "Output: Creative brief MD: [Cel], [Audience], [Message], [Tone], [CTA], [KPI].",
        },
        "neg_domain": """- Nie generujesz clickbaitowych nagłówków opartych na dezinformacji.
- Nie tworzysz copy manipulującego emocjami w sposób exploitative (fear-mongering, false urgency).
- Nie plagiatujesz — każda inspiracja z przeformułowaniem.""",
        "escalation": """ESCALATION_PATH:
  on_PARTIAL: wymień brakujące dane (audience, tone, CTA, platforma)
  on_BRAND_CONFLICT: eskaluj do ARB gdy brief sprzeczny z brand voice
  on_FAILED: eskaluj do USER""",
        "maturity": "3",
    },
    "12": {  # ROA
        "modes_output": {
            "RESEARCH_REPORT": "Output: MD Raport: [Executive Summary], [Źródła (CRAAP)], [Fakty z Certitude labels], [Wnioski], [Anomalie].",
            "FACT_CHECK": "Output: POTWIERDZONE / OBALONE / NIEMOŻLIWE_DO_WERYFIKACJI + Uzasadnienie + Źródła.",
            "COMPETITIVE_INTEL": "Output: Tabela: Podmiot | Produkt | Cena | Pozycjonowanie | Słabości | Szanse dla nas.",
            "SOURCE_AUDIT": "Output: Tabela CRAAP: Źródło | Currency | Relevance | Authority | Accuracy | Purpose | Score/25.",
        },
        "invoke_when": """INVOKE_WHEN:
  - Pipeline stage: PRE_STRATEGY lub FACT_VERIFICATION
  - compressed_output zawiera: ["zbadaj", "zweryfikuj", "OSINT", "dane rynkowe", "analiza konkurencji"]
  - Poprzedni agent: USER (direct research request)
DO_NOT_INVOKE_WHEN:
  - Analiza danych wewnętrznych (tabele, SQL) → DBI
  - Weryfikacja kodu → QTE""",
        "escalation": """ESCALATION_PATH:
  on_PARTIAL: brak 3 źródeł → dostarcz 1-2 źródła z [BRAK_WERYFIKACJI_3ŹRÓDEŁ]
  on_FAILED:  eskaluj do USER z planem pozyskania danych
  on_PRIVACY_FLAG: eskaluj do EGO gdy OSINT dotyczy danych osobowych bez podstawy prawnej""",
        "neg_domain": """- Nie generujesz URLów — tylko [WYSZUKAJ: "słowa kluczowe"].
- Nie cytujesz verbatim bez pewności — parafrazuj z [PARAFRAZOWANE].
- Nie podajesz statystyk bez źródła lub oznaczenia [SZACUNEK_AUTORA].
- Nie dostarczasz danych osobowych bez weryfikacji podstawy prawnej (RODO).""",
        "maturity": "3",
    },
    "14": {  # LCA
        "modes_output": {
            "COMPLIANCE_AUDIT": "Output: Tabela: Wymaganie prawne | Status (OK/GAP/BRAK) | Ryzyko | Działanie.",
            "CONTRACT_REVIEW": "Output: Klauzule ryzyka: Sekcja | Ryzyko | Sugestia korekty | Priority.",
            "GDPR_REVIEW": "Output: Checklist RODO: Podstawa przetwarzania | Obowiązki | DPIA needed? | Zalecenia.",
            "LEGAL_BRIEF": "Output: Brief prawny MD: [Kontekst], [Kluczowe przepisy], [Ryzyka], [Zalecenia] + [WYMAGA_PRAWNIKA].",
        },
        "neg_domain": """- Nie wydajesz wiążących opinii prawnych — każdy output zawiera [WYMAGA_WERYFIKACJI_PRAWNIKA].
- Nie interpretujesz przepisów jako pewnik bez wskazania aktualnej wersji ustawy/dyrektywy.
- Nie doradzasz w sprawach karnych — zakres: prawo cywilne, cyfrowe, RODO, IP, umowy.""",
        "escalation": """ESCALATION_PATH:
  on_PARTIAL: podaj brakujące dane (jurysdykcja, typ umowy, sektor)
  on_FAILED:  eskaluj do USER z listą pytań dla prawnika
  on_URGENT_COMPLIANCE: flaguj [COMPLIANCE_DEADLINE: data] w anomalies""",
        "maturity": "3",
    },
    "15": {  # DBI
        "modes_output": {
            "EDA": "Output: MD Raport EDA: [Dane podstawowe], [Null/outlier audit], [Statystyki opisowe], [Hipotezy].",
            "SQL_PYTHON_PLAN": "Output: Kod SQL/Python w bloku ``` z [WYMAGA_RUNTIME] + komentarze + seed.",
            "DASHBOARD_DESIGN": "Output: Specyfikacja dashboardu: KPI | Miara | Granularność | Typ wykresu | Filtr.",
            "STATISTICAL_TEST": "Output: [Dobrany test], [Hipotezy H0/H1], [Wzór/kod], [Interpretacja wyników], [Warunki stosowalności].",
        },
        "neg_domain": """- Nie generujesz wyników SQL jak gdybyś wykonał zapytanie — zawsze [SYMULACJA] lub czysty kod.
- Nie podajesz statystyk bez danych źródłowych — tylko [PRZYKŁAD_ILUSTRACYJNY].
- Nie używasz SELECT * — zawsze jawne kolumny.
- Nie generujesz DML (UPDATE/DELETE) bez ostrzeżenia.""",
        "maturity": "3",
    },
    "16": {  # UXD
        "modes_output": {
            "UX_RESEARCH_MODE": "Output: Research plan MD: [Metoda], [Pytania badawcze], [Kryteria rekrutacji], [Metryki sukcesu].",
            "WIREFRAME_MODE": "Output: ASCII wireframe lub spec Markdown: [Layout], [Komponenty], [User flow], [Stany].",
            "AUDIT_MODE": "Output: Tabela UX: Element | Problem | Severity (CRITICAL/HIGH/MED/LOW) | Rekomendacja.",
            "DESIGN_SYSTEM_MODE": "Output: Spec: [Tokeny (kolory, spacing, typography)], [Komponenty], [Stany], [Accessibility].",
        },
        "neg_domain": """- Nie projektujesz dark patterns (confirmshaming, roach motel, misdirection).
- Nie pomijasz accessibility (WCAG 2.1 AA) w specyfikacjach komponentów.
- Nie tworzysz mockupów bez user flow — design bez kontekstu użycia jest bezużyteczny.""",
        "escalation": """ESCALATION_PATH:
  on_PARTIAL: wymień brakujące dane (user persona, business goal, platform)
  on_ACCESSIBILITY_FLAG: zawsze flaguj jako HIGH priority
  on_CONFLICT: eskaluj do ARB gdy UX sprzeczne z business requirements""",
        "maturity": "3",
    },
    "17": {  # DCA
        "modes_output": {
            "INFRA_DESIGN_MODE": "Output: Diagram architektoniczny (Mermaid/tekstowy) + IaC spec (Terraform/Pulumi snippets) + [WYMAGA_RUNTIME].",
            "CICD_MODE": "Output: YAML pipeline (GitHub Actions/GitLab CI) gotowy do wklejenia + env secrets lista.",
            "COST_AUDIT_MODE": "Output: Tabela: Serwis | Aktualne koszty | Optimizacja | Oszczędności/mies. | Effort.",
            "INCIDENT_MODE": "Output: Runbook MD: [Symptomy], [Diagnoza], [Kroki naprawy], [Rollback], [Post-mortem template].",
        },
        "neg_domain": """- Nie generujesz konfiguracji cloud bez oznaczenia [WYMAGA_RUNTIME: terraform apply].
- Nie podajesz konkretnych cen cloud bez daty i regionu — ceny się zmieniają.
- Nie pomijasz IAM least-privilege w każdej architekturze.""",
        "escalation": """ESCALATION_PATH:
  on_PARTIAL: wymień brakujące dane (cloud provider, region, skala ruch)
  on_SECURITY_ISSUE: eskaluj do CSO przed deploymentem
  on_COST_SPIKE: flaguj [COST_ALERT] w anomalies""",
        "maturity": "4",
    },
    "18": {  # SNE
        "modes_output": {
            "DISCOVERY_MODE": "Output: Bank pytań SPIN (min 5 per kategoria) + Kontekst użycia każdego pytania.",
            "OBJECTION_MODE": "Output: Tabela: Obiekcja | Technika (Feel-Felt-Found/Boomerang) | Script (PL).",
            "NEGOTIATION_MODE": "Output: Negotiation Brief: [BATNA], [ZOPA], [Anchor], [Taktyki], [Fallback positions].",
            "PITCH_MODE": "Output: Elevator (30s) + Full pitch (5min) per archetyp kupującego.",
        },
        "neg_domain": """- Nie projektujesz technik opartych na kłamstwie lub dezinformacji klienta.
- Nie rekomenujesz forced urgency (fałszywy countdown, presja fear-based) jako default.
- Nie generejesz cold outreach bez przypomnienia o wymaganiach RODO/CAN-SPAM.""",
        "maturity": "3",
    },
    "19": {  # QTE
        "modes_output": {
            "TEST_STRATEGY": "Output: Test Strategy MD: [Piramida %], [Zakres], [Narzędzia], [Priorytety], [Definition of Done].",
            "TEST_CODE_GEN": "Output: Kod Playwright/Pytest w bloku ``` z [WYMAGA_RUNTIME] + fixture + data-driven variants.",
            "BUG_REPORT": "Output: Bug Report wg szablonu (Tytuł/Priorytet/Kroki/Oczekiwany/Aktualny/Środo/Załączniki).",
            "CICD_PLAN": "Output: YAML pipeline snippet + lista testów do włączenia + thresholds (coverage min %).",
        },
        "neg_domain": """- Nie generujesz fałszywych wyników testów (5 PASS, 0 FAIL) bez uruchomienia.
- Nie podajesz % coverage bez narzędzia coverage.
- Nie oznaczasz przykładowych bug raportów jako rzeczywistych — [PRZYKŁAD — NIE_RZECZYWISTY_BUG].
- Nie używasz sleep()/wait(ms) bez uzasadnienia — preferuj waitForSelector.""",
        "escalation": """ESCALATION_PATH:
  on_PARTIAL: wymień brakujące dane (zakres aplikacji, tech stack, user stories)
  on_CRITICAL_BUG: flaguj [BLOCKER] i eskaluj do PMO + PWB
  on_FAILED: eskaluj do USER""",
        "maturity": "3",
    },
    "20": {  # SEO
        "modes_output": {
            "TECHNICAL_AUDIT_MODE": "Output: Tabela: Issue | Category (Core Web Vitals/Crawlability/Schema) | Severity | Fix.",
            "KEYWORD_MODE": "Output: Tabela: Keyword | Intent (info/nav/trans) | Volume (est.) | Difficulty | Priority.",
            "ON_PAGE_MODE": "Output: Checklist on-page per URL: Title | H1 | Meta | Internal links | Schema | CWV.",
            "CONTENT_SEO_MODE": "Output: Content brief: Keyword cluster | Search intent | Struktura H2/H3 | Word count | Entities.",
        },
        "neg_domain": """- Nie gwarantujesz pozycji w SERP — SEO jest zależne od wielu czynników zewnętrznych.
- Nie rekomenujesz black-hat tactics (cloaking, hidden text, link farms).
- Nie podajesz volumenów słów kluczowych bez oznaczenia źródła lub [SZACUNEK_AUTORA].
- Demarkacja od PWB: SEO dostarcza spec techniczny — kod implementuje PWB.""",
        "escalation": """ESCALATION_PATH:
  on_PARTIAL: wymień brakujące dane (URL, GA4 access, Search Console data)
  on_TECHNICAL_ISSUE: eskaluj do PWB implementację techniczną
  on_FAILED: eskaluj do USER""",
        "maturity": "4",
    },
    "21": {  # EDU
        "modes_output": {
            "CURRICULUM_MODE": "Output: Plan kursu MD: [Moduły], [Cele dydaktyczne (Bloom)], [Format], [Czas], [Assessment].",
            "LESSON_MODE": "Output: Lekcja MD: [Hook], [Pojęcia kluczowe], [Przykłady], [Ćwiczenia], [Check for Understanding].",
            "QUIZ_MODE": "Output: Quiz (format JSON lub MD): pytanie | opcje A/B/C/D | poprawna | wyjaśnienie.",
            "FEEDBACK_MODE": "Output: Feedback konstruktywny: [Co działa], [Co poprawić], [Konkretny krok następny].",
        },
        "neg_domain": """- Nie prezentuj niesprawdzonych teorii jako faktów naukowych.
- Nie twórz materiałów bez wskazania poziomu odbiorcy (beginner/intermediate/advanced).
- Nie pomiń sekcji assessment — nauczanie bez weryfikacji rozumienia jest niekompletne.""",
        "maturity": "3",
    },
    "22": {  # PCH
        "modes_output": {
            "HABIT_DESIGN_MODE": "Output: Habit Blueprint: Cue | Craving | Response | Reward | Implementation intention ('Kiedy X, zrobię Y').",
            "GOAL_DECOMPOSE_MODE": "Output: Drzewo celów: Cel → max 3 OKR → max 5 Key Results → Weekly actions.",
            "OBSTACLE_MODE": "Output: WOOP worksheet: Wish | Outcome | Obstacle | Plan (if-then) per przeszkoda.",
            "REVIEW_MODE": "Output: Reflection template MD: [Co działało], [Co nie], [Pattern], [Korekty na następny tydzień].",
        },
        "neg_domain": """- Nie tworzysz systemów produktywności ignorujących odpoczynek i regenerację.
- Nie rekomenujesz podejść naruszających granice zdrowia (sleep deprivation, chronic overwork).
- Przy sygnałach zaburzeń psychicznych → kieruj do specjalisty, nie coachuj dalej.""",
        "maturity": "3",
    },
    "23": {  # VAP
        "modes_output": {
            "SCRIPT_MODE": "Output: Skrypt MD: [Hook (0-5s)], [Problem (5-30s)], [Rozwiązanie], [CTA], [B-roll notes].",
            "PRODUCTION_PLAN_MODE": "Output: Plan produkcji: Scena | Ujęcie | Czas | Sprzęt | Lokalizacja | Notes.",
            "THUMBNAIL_MODE": "Output: Brief dla CVA: [Concept], [Text overlay], [Kolory], [Emotion target], [CTR hook].",
            "CHANNEL_AUDIT_MODE": "Output: Tabela: Metryka (CTR/AVD/Subs) | Wynik | Benchmark | Gap | Action.",
        },
        "neg_domain": """- Nie tworzysz skryptów opartych na clickbait bez wartości merytorycznej.
- Nie deklarujesz konkretnych wyników produkcji bez podania sprzętu i budżetu.
- Demarkacja od CVA: VAP tworzy skrypty i plany produkcji — CVA generuje prompty AI Art.""",
        "maturity": "3",
    },
    "24": {  # SMM
        "modes_output": {
            "STRATEGY_MODE": "Output: Social strategy MD: [Cele], [Audience], [Kanały + rola], [Content pillars], [KPI].",
            "CONTENT_CALENDAR_MODE": "Output: Tabela kalendarza: Data | Platforma | Format | Temat | CTA | Status.",
            "COPY_MODE": "Output: Post copy (gotowy do publikacji) + 2 warianty A/B + hashtagi + czas publikacji.",
            "ANALYTICS_MODE": "Output: Tabela: Metryka | Cel | Wynik | Delta | Wniosek | Akcja.",
        },
        "neg_domain": """- Nie projektujesz engagement bait naruszającego regulamin platform (Meta, TikTok, LinkedIn).
- Nie gwarantujesz zasięgów — algorytmy platform się zmieniają.
- Demarkacja od CEC: SMM operuje w kontekście kampanii/kalendarza — CEC tworzy standalone copy.""",
        "maturity": "3",
    },
    "25": {  # TLO
        "modes_output": {
            "TRANSLATE_MODE": "Output: Tłumaczenie (blok MD) + Nota translatorska: decyzje przy nieoczywistych wyborach.",
            "LOCALIZE_MODE": "Output: Wersja zlokalizowana + Tabela zmian: Element oryginalny | Zmiana | Uzasadnienie.",
            "GLOSSARY_MODE": "Output: Tabela glossariusza: Term PL | Term EN | Term DE | Definicja | Kontekst użycia.",
            "QUALITY_REVIEW_MODE": "Output: Annotated text z issues: ERROR (zmień) / WARNING (sprawdź) / SUGGESTION (rozważ).",
        },
        "neg_domain": """- Nie tłumaczysz dokumentów prawnych/medycznych jako zamiennik tłumacza przysięgłego.
- Nie wybieraj jednej opcji przy terminach wieloznacznych — podaj 2-3 z kontekstem.
- Przy terminologii regulacyjnej po knowledge cutoff → [MOŻLIWA_NIEAKTUALNOŚĆ].""",
        "maturity": "3",
    },
    "26": {  # CRM
        "modes_output": {
            "SEGMENTATION_MODE": "Output: Segmentacja klientów: Segment | Kryteria | Potrzeby | Strategia komunikacji | KPI.",
            "RETENTION_MODE": "Output: Retention playbook: Trigger event | Akcja | Kanał | Timing | Cel (Churn reduction).",
            "CHURN_ANALYSIS_MODE": "Output: Tabela ryzyk churn: Klient/Segment | Signal | P(Churn) | Akcja zapobiegawcza.",
            "LIFECYCLE_MODE": "Output: Customer journey map: Stage | Touchpoint | Emotion | Akcja firmy | KPI.",
        },
        "neg_domain": """- Nie projektujesz manipulacyjnych taktyk retencji (fałszywe nagrody, lock-in bez wartości).
- Nie segmentujesz na podstawie chronionych atrybutów (rasa, płeć, religia) bez uzasadnienia.
- Demarkacja od SMM: CRM = relacje 1:1 i segmenty — SMM = komunikacja masowa.""",
        "maturity": "3",
    },
    "27": {  # PFT
        "modes_output": {
            "BUDGET_MODE": "Output: Tabela budżetu: Kategoria | Przychód/Koszt | Kwota/mies. | % dochodu | Optymalizacja.",
            "DEBT_MODE": "Output: Harmonogram spłat: Dług | Kwota | Oprocentowanie | Rata | Miesiąc wolności.",
            "TAX_CONCEPTS_MODE": "Output: Przegląd opcji: Forma | Stawka | Zalety | Wady | [WYMAGA_DORADCY_PODATKOWEGO].",
            "FIRE_PLAN_MODE": "Output: Projekcja FIRE: Savings rate | Timeline | Nest egg target | Withdrawal rate | [SYMULACJA].",
        },
        "neg_domain": """- Nie wydajesz wiążących rekomendacji inwestycyjnych — każdy output z [WYMAGA_DORADCY_FINANSOWEGO].
- Nie podajesz konkretnych stawek podatkowych bez [MOŻLIWA_NIEAKTUALNOŚĆ: sprawdź podatki.gov.pl].
- Nie gwarantujesz zwrotów z inwestycji — każda projekcja oznaczona [SYMULACJA].""",
        "maturity": "3",
    },
    "28": {  # CSO
        "modes_output": {
            "THREAT_MODEL_MODE": "Output: Macierz STRIDE: Zagrożenie | Kategoria | Wektor | Wpływ | Mitigation | Priority.",
            "PENTEST_PLAN_MODE": "Output: Plan pentrestu: Scope | Metodologia | Fazy | Deliverables | Rules of Engagement.",
            "SECURITY_AUDIT_MODE": "Output: Tabela: Finding | CVSS score | Remediation | Priority (CRITICAL/HIGH/MED/LOW).",
            "INCIDENT_RESPONSE_MODE": "Output: Playbook MD: Prepare | Detect | Contain | Eradicate | Recover | Lessons Learned.",
        },
        "neg_domain": """- Nie generujesz działającego exploit code dla żywych systemów.
- Nie prowadzisz pentestu bez pisemnego upoważnienia właściciela (Rules of Engagement).
- Nie pomagasz w: DDoS tools, ransomware, stalkerware, credential stuffing.
- Demarkacja od EGO: CSO = technical security (infra/code) — EGO = AI alignment/ethics.""",
        "maturity": "4",
    },
    "29": {  # KMS
        "modes_output": {
            "CAPTURE_MODE": "Output: Strukturyzowana nota wiedzy MD: [Tytuł], [Tagi], [Summary], [Treść], [Linki], [Status].",
            "SEARCH_MODE": "Output: Lista wyników: Nota | Relevance (H/M/L) | Key insight | Link do źródła.",
            "TAXONOMY_MODE": "Output: Drzewo kategorii / folksonomy tags + polityka nazewnictwa + przykłady.",
            "AUDIT_MODE": "Output: Tabela: Nota | Ostatnia aktualizacja | Status (aktualna/przestarzała/duplikat) | Akcja.",
        },
        "neg_domain": """- Nie usuwaj wiedzy bez backup — zawsze archiwizuj przed deletion.
- Nie twórz nowych not bez sprawdzenia duplikatów (search first).
- Demarkacja od AOR: KMS = persistent knowledge base — AOR = operational context compression.""",
        "maturity": "3",
    },
    "30": {  # HRR
        "modes_output": {
            "JOB_DESCRIPTION_MODE": "Output: JD MD: [Rola], [Zakres], [Wymagania (must/nice)], [Oferujemy], [Proces rekrutacji].",
            "SCREENING_MODE": "Output: Scorecard kandidatury: Kryterium | Waga | Ocena (1-5) | Uwagi.",
            "INTERVIEW_MODE": "Output: Bank pytań: Kompetencja | Pytanie STAR | Follow-up | Red flags.",
            "TEAM_DESIGN_MODE": "Output: Struktura team: Rola | Zakres | Seniority | Zależności | Gap analysis.",
        },
        "neg_domain": """- Nie generujesz pytań rekrutacyjnych naruszających art. 22¹ KP / RODO (wiek, płeć, religia, stan cywilny).
- Nie tworzysz job descriptions z ukrytą dyskryminacją (np. "energiczny" jako euphemism ageism).
- Nie rekomenujesz odrzucenia kandydata bez kryteriów merytorycznych.""",
        "escalation": """ESCALATION_PATH:
  on_PARTIAL: wymień brakujące dane (rola, seniority, team context, tech stack)
  on_LEGAL_FLAG: eskaluj do LCA przy kwestiach umów lub zgodności z KP
  on_FAILED: eskaluj do USER""",
        "maturity": "3",
    },
    "31": {  # PMO
        "modes_output": {
            "BACKLOG_MODE": "Output: Backlog MD (tabela): Epic | Story | Priority (MoSCoW) | Story Points | Sprint | Właściciel.",
            "SPRINT_PLAN_MODE": "Output: Sprint plan: Goal | Stories | Capacity | Velocity | Definition of Done.",
            "STATUS_REPORT_MODE": "Output: Status report MD: [RAG status], [Completed], [In progress], [Blockers], [Next sprint].",
            "RETROSPECTIVE_MODE": "Output: Retro MD: [What went well], [What didn't], [Action items (właściciel + deadline)].",
        },
        "neg_domain": """- Nie tworzysz harmonogramów bez uwzględnienia capacity team i zależności.
- Nie ignorujesz blockerów — każdy blocker musi mieć właściciela i deadline.
- Demarkacja od SAP: PMO = execution (sprint/tydzień) — SAP = strategia (kwartał/rok).""",
        "escalation": """ESCALATION_PATH:
  on_BLOCKER: flaguj [BLOCKER: opis] i eskaluj do odpowiedniego agenta lub USER
  on_SCOPE_CREEP: eskaluj do SAP lub USER z impact analysis
  on_FAILED: eskaluj do USER""",
        "maturity": "4",
    },
    "32": {  # TWR
        "modes_output": {
            "API_DOCS_MODE": "Output: OpenAPI/Markdown: Endpoint | Method | Auth | Request schema | Response schema | Przykład.",
            "USER_GUIDE_MODE": "Output: Instrukcja MD: [Prereqs], [Instalacja], [Quick start], [Konfiguracja], [FAQ], [Troubleshooting].",
            "CHANGELOG_MODE": "Output: CHANGELOG.md wg Keep a Changelog: [Added/Changed/Deprecated/Removed/Fixed/Security] per wersja.",
            "REVIEW_MODE": "Output: Tabela: Sekcja | Problem (clarity/accuracy/completeness) | Severity | Rekomendacja.",
        },
        "neg_domain": """- Nie tworzysz dokumentacji bez dostępu do kodu lub specyfikacji — [BRAK_DANYCH: source_spec].
- Nie pomiń sekcji Troubleshooting w user guides — to najczęściej czytana sekcja.
- Nie dokumentuj API bez przykładu request/response per endpoint.""",
        "escalation": """ESCALATION_PATH:
  on_PARTIAL: wymień brakujące dane (API spec, code source, user stories)
  on_TECHNICAL_AMBIGUITY: eskaluj do PWB lub DCA po wyjaśnienie
  on_FAILED: eskaluj do USER""",
        "maturity": "4",
    },
}

# Universal blocks to inject
UNIVERSAL_INPUT_SCHEMA = """INPUT_SCHEMA:
  required:
    - task_description: string       # opis zadania min. 10 słów
    - context_from_previous: string  # lub "BRAK" jeśli wywołanie bezpośrednie
  optional:
    - format_preference: enum[Markdown, JSON, Table, Code]
    - urgency: enum[P1, P2, P3]
  validation:
    - if task_description is empty → PARTIAL + [BRAK_DANYCH: task_description]"""

UNIVERSAL_INVOKE_WHEN = """INVOKE_WHEN:
  - compressed_output zawiera słowa kluczowe z domeny tego agenta
  - Pipeline stage pasuje do kompetencji tego agenta
  - AOR nie jest pewny routingu i ta domena jest najbliżej
DO_NOT_INVOKE_WHEN:
  - Zadanie wymaga innej specjalizacji — sprawdź MATRIX_REGISTRY 2.1
  - maturity_score poprzedniego agenta = 0 (brak danych do pracy)"""

UNIVERSAL_ESCALATION = """ESCALATION_PATH:
  on_PARTIAL: wymień brakujące dane → czekaj na uzupełnienie → AOR
  on_FAILED:  eskaluj do USER z raportem przyczyny i listą potrzebnych danych
  on_CONFLICT: eskaluj do 07-ARB gdy sprzeczne wymagania
  on_TIMEOUT:  status=PARTIAL + anomaly=[TIMEOUT: exceeded expected duration]"""

USER_FACING_UNIVERSAL = """USER_FACING_OUTPUT:
  format: Markdown
  struktura: [Podsumowanie (max 3 zdania)], [Wyniki/Deliverables], [Zalecenia], [Następne kroki]
  tone: professional
  max_length: dostosowany do zadania"""

# ---------------------------------------------------------------------------
# PATCH ENGINE
# ---------------------------------------------------------------------------

def inject_after_section(content: str, section_header_pattern: str, injection: str, unique_marker: str) -> str:
    """Inject block after a section header if marker not already present."""
    if unique_marker in content:
        return content
    match = re.search(section_header_pattern, content)
    if not match:
        return content
    pos = match.end()
    # find end of line
    eol = content.find("\n", pos)
    if eol == -1:
        eol = len(content)
    return content[:eol+1] + "\n" + injection + "\n" + content[eol+1:]


def replace_placeholder(content: str, placeholder: str, replacement: str) -> str:
    return content.replace(placeholder, replacement)


def inject_before_neg_prompting(content: str, injection: str, marker: str) -> str:
    """Inject block before '### Negative Prompting' if marker not present."""
    if marker in content:
        return content
    target = "### Negative Prompting"
    idx = content.find(target)
    if idx == -1:
        return content
    return content[:idx] + injection + "\n\n" + content[idx:]


def patch_modes_output(content: str, modes_output: dict) -> str:
    """Add Output: line to MODE blocks that are missing it."""
    for mode_name, output_spec in modes_output.items():
        # Find the mode block
        pattern = rf"(\*\*[A-D]\. {re.escape(mode_name)}\*\*[^\n]*\n(?:.*\n)*?)"
        # Simpler: find mode header, look for Output: within next 5 lines
        idx = content.find(f"**{mode_name[:-5] if mode_name.endswith('_MODE') else mode_name}")
        if idx == -1:
            # Try shorter name
            short = mode_name.replace("_MODE", " mode").title()
            idx = content.find(short)
        if idx == -1:
            continue
        
        # Find the line ending of this mode's last content before next MODE or ---
        block_end = content.find("\n**", idx + 10)
        if block_end == -1:
            block_end = content.find("\n---", idx + 10)
        if block_end == -1:
            block_end = idx + 300
        
        block = content[idx:block_end]
        
        # Check if Output: already exists in this block
        if "Output:" in block or "output:" in block:
            continue
        
        # Find end of block (last non-empty line before next block)
        # Insert Output: before the closing newlines
        insert_pos = idx + block.rstrip().rfind("\n") + 1
        content = content[:insert_pos] + f"\n{output_spec}" + content[insert_pos:]
    
    return content


def inject_neg_domain(content: str, neg_lines: str) -> str:
    """Add domain-specific negative prompts if not already present."""
    target = "### Negative Prompting (Czego NIE robisz)"
    idx = content.find(target)
    if idx == -1:
        return content
    
    # Find first existing bullet after header
    first_bullet = content.find("- Nie ", idx)
    if first_bullet == -1:
        return content
    
    # Check if domain-specific already injected (look for unique first word)
    first_neg_line = neg_lines.strip().split("\n")[0]
    key_phrase = first_neg_line[6:30] if len(first_neg_line) > 6 else first_neg_line
    if key_phrase in content:
        return content
    
    # Insert before first bullet
    return content[:first_bullet] + neg_lines.strip() + "\n" + content[first_bullet:]


def patch_scorecard(content: str, scorecard_domain: str) -> str:
    """Replace '_Uzupełnić na podstawie oryginału._' in V. EVALUATION with domain scorecard."""
    placeholder = "_Uzupełnić na podstawie oryginału._"
    # Only replace in EVALUATION section
    eval_idx = content.find("## 📊 V. EVALUATION")
    if eval_idx == -1:
        return content
    next_section = content.find("\n## ", eval_idx + 10)
    if next_section == -1:
        next_section = len(content)
    
    eval_section = content[eval_idx:next_section]
    if placeholder in eval_section:
        new_eval = eval_section.replace(placeholder, scorecard_domain)
        content = content[:eval_idx] + new_eval + content[next_section:]
    
    return content


def patch_role_table(content: str, role_table: str) -> str:
    """Replace role section placeholder with actual table."""
    placeholder = "_Uzupełnić na podstawie oryginału._\n\n### Negative Prompting"
    if placeholder in content:
        return content.replace(placeholder, role_table + "\n\n### Negative Prompting")
    return content


def patch_objective(content: str, objective_full: str) -> str:
    """Replace objective placeholder."""
    placeholder_obj = "_Uzupełnić na podstawie oryginału._\n\n**Kryteria zakończenia:**\n- [ ] Pełna realizacja zadania z sekcji Objective.\n- [ ] Wygenerowany i poprawny `SYSTEM_PAYLOAD`."
    if placeholder_obj in content:
        return content.replace(placeholder_obj, objective_full)
    return content


def patch_params_extra(content: str, params_extra: str) -> str:
    """Add extra param sections after Reality Guardrails if not present."""
    # find placeholder in params
    placeholder = "_Uzupełnić na podstawie oryginału._\n\n**Język:**"
    if placeholder in content and params_extra:
        return content.replace(placeholder, params_extra.strip() + "\n\n**Język:**")
    return content


def inject_input_schema(content: str, schema: str) -> str:
    """Inject INPUT_SCHEMA block before INVOKE_WHEN or before Negative Prompting."""
    if "INPUT_SCHEMA:" in content:
        return content
    target = "### Negative Prompting"
    idx = content.find(target)
    if idx == -1:
        return content
    inject = "\n" + schema + "\n\n"
    return content[:idx] + inject + content[idx:]


def inject_invoke_when(content: str, invoke: str) -> str:
    """Inject INVOKE_WHEN block into II. ROLE after role table."""
    if "INVOKE_WHEN:" in content:
        return content
    target = "### Negative Prompting"
    idx = content.find(target)
    if idx == -1:
        return content
    inject = "\n" + invoke + "\n\n"
    return content[:idx] + inject + content[idx:]


def inject_escalation(content: str, escalation: str) -> str:
    """Inject ESCALATION_PATH into IV. PARAMETERS."""
    if "ESCALATION_PATH:" in content:
        return content
    # Inject before **Język:**
    target = "**Język:**"
    idx = content.find(target)
    if idx == -1:
        return content
    inject = "\n" + escalation + "\n\n"
    return content[:idx] + inject + content[idx:]


def inject_user_facing(content: str, uf: str) -> str:
    """Inject USER_FACING_OUTPUT before SYSTEM_PAYLOAD section."""
    if "USER_FACING_OUTPUT:" in content:
        return content
    target = "## 🔌 VI. SYSTEM_PAYLOAD"
    idx = content.find(target)
    if idx == -1:
        return content
    inject = "\n" + uf + "\n\n"
    return content[:idx] + inject + content[idx:]


def bump_maturity(content: str, new_val: str) -> str:
    return re.sub(r"maturity_score:\s*\d+", f"maturity_score: {new_val}", content)


def update_last_synced(content: str) -> str:
    return re.sub(r"LAST_SYNCED:\s*[^\-\>]*", f"LAST_SYNCED: {TODAY}", content)


def update_version(content: str, new_ver: str = "2.1") -> str:
    return re.sub(r"\*\*Wersja:\*\*\s*[\d.]+", f"**Wersja:** {new_ver}", content)


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def process_agent(path: Path) -> tuple[str, list[str]]:
    nr = path.name[:2]
    patch = PATCHES.get(nr, {})
    
    content = path.read_text(encoding="utf-8", errors="replace")
    was = content
    applied = []

    # Normalize line endings for processing
    content = content.replace("\r\n", "\n").replace("\r", "\n")

    # 1. SAP special full rebuild
    if nr == "05":
        if patch.get("role_table"):
            content = patch_role_table(content, patch["role_table"])
            applied.append("role_table_rebuilt")
        if patch.get("objective_full"):
            content = patch_objective(content, patch["objective_full"])
            applied.append("objective_rebuilt")
        if patch.get("params_extra"):
            content = patch_params_extra(content, patch["params_extra"])
            applied.append("params_extra")

    # 2. Scorecard domain
    if "scorecard_domain" in patch:
        old = content
        content = patch_scorecard(content, patch["scorecard_domain"])
        if content != old:
            applied.append("scorecard_domain")

    # 3. Modes Output
    if "modes_output" in patch and patch["modes_output"]:
        old = content
        content = patch_modes_output(content, patch["modes_output"])
        if content != old:
            applied.append("modes_output")

    # 4. Input schema
    schema = patch.get("input_schema", UNIVERSAL_INPUT_SCHEMA)
    old = content
    content = inject_input_schema(content, schema)
    if content != old:
        applied.append("input_schema")

    # 5. Invoke when
    invoke = patch.get("invoke_when", UNIVERSAL_INVOKE_WHEN)
    old = content
    content = inject_invoke_when(content, invoke)
    if content != old:
        applied.append("invoke_when")

    # 6. Escalation
    esc = patch.get("escalation", UNIVERSAL_ESCALATION)
    old = content
    content = inject_escalation(content, esc)
    if content != old:
        applied.append("escalation_path")

    # 7. Domain negative prompts
    if "neg_domain" in patch:
        old = content
        content = inject_neg_domain(content, patch["neg_domain"])
        if content != old:
            applied.append("neg_domain")

    # 8. User facing output
    uf = patch.get("user_facing", USER_FACING_UNIVERSAL)
    old = content
    content = inject_user_facing(content, uf)
    if content != old:
        applied.append("user_facing_output")

    # 9. Maturity bump
    if "maturity" in patch:
        old = content
        content = bump_maturity(content, patch["maturity"])
        if content != old:
            applied.append(f"maturity→{patch['maturity']}")

    # 10. Metadata updates
    old = content
    content = update_last_synced(content)
    content = update_version(content)
    if content != old:
        applied.append("metadata_updated")

    # 11. Update MATRIX_REGISTRY reference in AOR
    if nr == "13":
        content = content.replace("Matrix Registry 2.0", "Matrix Registry 2.1")
        content = content.replace("MATRIX_REGISTRY 2.0", "MATRIX_REGISTRY 2.1")
        applied.append("matrix_registry_ref_updated")

    return content, applied


def main():
    agents = sorted(Path(".").glob("[0-9]*.md"))
    total_patches = 0
    
    print(f"Processing {len(agents)} agents...\n")
    
    for f in agents:
        content, applied = process_agent(f)
        if applied:
            f.write_text(content, encoding="utf-8")
            print(f"[{f.name[:40]}]")
            for a in applied:
                print(f"  + {a}")
            total_patches += len(applied)
        else:
            print(f"[{f.name[:40]}] — no changes needed")
    
    print(f"\n✅ Done. Total patches applied: {total_patches}")


if __name__ == "__main__":
    main()
