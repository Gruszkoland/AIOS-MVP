# Matrix Registry 2.1: Ekosystem 32 Agentów
> **SSoT:** MAPPING_32.md (canonical) → MATRIX_REGISTRY_2.1.md (routing)
> **Aktualizacja:** 2026-04-22
> **Zmiany v2.0→v2.1:** Ujednolicono nazwy i akronimy z MAPPING_32 (6 kolizji naprawionych: QPA, BL, PCH, VAP, SNE, CVA)
> **Reguła bezpieczeństwa:** niepewność wyboru > 30% → eskaluj do 07-ARB

| ID | Akronim | Nazwa Canoniczna (wg MAPPING_32) | Kompetencja Kluczowa | Kiedy wywołać (Trigger) |
|:---:|:---:|---|---|---|
| 01 | MPG | Master Prompt Generator | Inżynieria promptów, tworzenie i audyt agentów | Gdy trzeba stworzyć, naprawić lub ocenić agenta / prompt |
| 02 | PWB | Programator Webowy Full-Stack | Kodowanie aplikacji webowych i backendów | Gdy projekt wchodzi w implementację kodu |
| 03 | CVA | Creator of Visualization and Animation | Generowanie obrazów, kierunek wizualny, prompty AI Art | Gdy potrzebna jest warstwa wizualna lub generatywna grafika |
| 04 | QPA | Quantum Pattern Analyst | Analiza techniczna rynków, detekcja manipulacji (Wyckoff / Smart Money) | Przy zadaniach analizy finansowej i rynkowej |
| 05 | SAP | Strategic Architect & Planner | Architektura systemowa, planowanie strategiczne, roadmapping | Przed kodowaniem — do projektowania struktury i strategii |
| 06 | BL | BoosterLever | Growth hacking, dźwignie marketingowe, monetyzacja | Gdy trzeba przyspieszyć wzrost lub zidentyfikować dźwignie |
| 07 | ARB | The Arbiter | Rozstrzyganie konfliktów, podejmowanie decyzji GO/NO-GO | Gdy są konkurencyjne ścieżki decyzji lub niepewność > 30% |
| 08 | EGO | Etos Guardian OS | Bezpieczeństwo AI, TEE Enclave, spójność etyczna systemu | Przy incydentach bezpieczeństwa lub kalibracji wartości systemu |
| 09 | CTG | Chronos The Guardian | Duchowa mądrość, archetypowa interpretacja, czas i rytm | Gdy kontekst wymaga perspektywy długofalowej lub symbolicznej |
| 10 | ECHO | Echo Archetypów | Meta-persona, dynamiczne wcielanie archetypów, kompresja kontekstu | Po długiej sesji lub gdy potrzebna zmiana persony / kondensacja |
| 11 | CEC | Content Engine & Copywriter | Copywriting konwersyjny, content marketing, redakcja | Gdy tekst ma być bardziej angażujący lub konwertujący |
| 12 | ROA | Research & OSINT Agent | Deep research, OSINT, analiza źródeł i wiarygodności | Na początku zadań badawczych lub przy weryfikacji danych |
| 13 | AOR | Agent Orchestrator | Routing, handoff, delegowanie, kompresja kontekstu między agentami | Zawsze jako kontroler przepływu — wejście i wyjście pipeline'u |
| 14 | LCA | Legal & Compliance Advisor | Prawo cyfrowe, RODO/GDPR, compliance | Gdy temat dotyczy danych osobowych, umów lub regulacji |
| 15 | DBI | Data Analyst & BI | Analiza danych, SQL, Business Intelligence, raportowanie | Gdy trzeba policzyć, zweryfikować dane lub zbudować raport |
| 16 | UXD | UX UI Designer | UX Research, user flow, makiety, interfejs | Przed implementacją frontendu — do projektowania doświadczeń |
| 17 | DCA | DevOps & Cloud Architect | CI/CD, infrastruktura cloud (AWS/GCP/Azure), deployment | Gdy kod jest gotowy do wdrożenia lub potrzeba architektury chmury |
| 18 | SNE | Sales & Negotiation Expert | Sprzedaż B2B/B2C, negocjacje, zamykanie transakcji | Przy projektowaniu procesów sprzedażowych i negocjacyjnych |
| 19 | QTE | QA & Test Engineer | Quality Assurance, testy automatyczne (Playwright/Cypress/Pytest) | Po implementacji, przed release — scenariusze testowe i bugi |
| 20 | SEO | SEO Specialist | SEO techniczne, on-page optimization, widoczność organiczna | Przy treściach i stronach publicznych wymagających pozycjonowania |
| 21 | EDU | Educator & Tutor | E-learning, pedagogika, projektowanie materiałów edukacyjnych | Gdy celem jest edukacja użytkownika lub tworzenie kursów |
| 22 | PCH | Personal Coach | Rozwój osobisty, nawyki (Atomic Habits), coaching | Przy zadaniach związanych z rozwojem kompetencji i nawyków |
| 23 | VAP | Video & Audio Producer | Produkcja video, skrypty YouTube, audio | Przy produkcji treści wideo i audio oraz skryptach |
| 24 | SMM | Social Media Manager | Social media strategy, content calendar, operacyjne prowadzenie social | Przy kalendarzach publikacji, kampaniach i zarządzaniu kanałami |
| 25 | TLO | Translator & Localizer | Tłumaczenia PL↔EN↔DE, lokalizacja kulturowa | Przy wejściu na rynki zagraniczne lub adaptacji treści |
| 26 | CRM | CRM & Customer Success | Customer Relationship Management, retencja, lojalność | Gdy projekt dotyczy relacji z klientami i utrzymania ich |
| 27 | PFT | Personal Finance & Tax | Finanse osobiste, budżetowanie, podatki | Gdy trzeba policzyć koszty, zyski lub kwestie podatkowe |
| 28 | CSO | Cybersecurity Specialist | Offensive security, defensive security, STRIDE/OWASP | Przed deploymentem i przy incydentach bezpieczeństwa |
| 29 | KMS | Knowledge Manager | Knowledge management, bazy wiedzy, pamięć organizacyjna | Gdy trzeba zapisać, ustrukturyzować lub przeszukać wiedzę |
| 30 | HRR | HR & Recruitment | Rekrutacja IT/biznes, job descriptions, budowanie zespołów | Gdy potrzebne role, hiring plan lub ocena kandydatów |
| 31 | PMO | Product Manager | Product strategy, backlog management, harmonogramy, milestones | Do kontroli zakresu, czasu i priorytetyzacji backlogu |
| 32 | TWR | Technical Writer | Dokumentacja techniczna, API docs, instrukcje dla użytkowników | Po implementacji — dla użytkowników końcowych i deweloperów |

---

| 33 | EVA | Evaluation & Observability Architect | Benchmarking, regression detection, drift monitoring, EvalOps | Gdy potrzebna ocena jakości ekosystemu, regression test lub postmortem |

## Reguły routingu dla AOR (#13)

| Sytuacja | Akcja |
|---|---|
| Jedno dopasowanie kompetencyjne | Wywołaj agenta bezpośrednio |
| Dwa równorzędne dopasowania | Eskaluj do **07-ARB** |
| Niepewność > 30% | Eskaluj do **07-ARB** |
| Status PARTIAL lub FAILED | Pętla naprawcza (retry lub reroute) przed przejściem dalej |
| Incydent bezpieczeństwa | Zawsze **28-CSO** przed deploymentem |
| Sprzeczność akronimów | Używaj MAPPING_32 jako SSoT |

---

## Zmiany v2.0 → v2.1 (diff kolizji)

| ID | Akronim | Stara nazwa w v2.0 | Nowa nazwa w v2.1 | Typ kolizji |
|:---:|:---:|---|---|:---:|
| 03 | CVA | Creative Visual Architect | Creator of Visualization and Animation | Nazwa |
| 04 | QPA | Quality Process Analyst | Quantum Pattern Analyst | ❌ Semantyczna |
| 06 | BL  | Business Logic | BoosterLever | ❌ Semantyczna |
| 18 | SNE | Social Engineering | Sales & Negotiation Expert | ❌ Semantyczna |
| 22 | PCH | Prompt Chaining | Personal Coach | ❌ Semantyczna |
| 23 | VAP | Viral Psychology | Video & Audio Producer | ❌ Semantyczna |

<!-- REGISTRY_VERSION: 2.1 -->
<!-- SSoT: MAPPING_32.md -->
<!-- LAST_SYNCED: 2026-04-22 -->
